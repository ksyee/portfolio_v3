
  # 포트폴리오_v3

  This is a code bundle for 포트폴리오_v3. The original project is available at https://www.figma.com/design/ncloVf5Jvih1KLRCMCkkop/%ED%8F%AC%ED%8A%B8%ED%8F%B4%EB%A6%AC%EC%98%A4_v3.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  