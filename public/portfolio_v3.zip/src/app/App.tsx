import { useState, useEffect, useMemo } from "react";
import { RouterProvider, createBrowserRouter, Outlet } from "react-router";
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";
import { CursorGlow } from "./components/CursorGlow";
import { InteractiveBackground } from "./components/InteractiveBackground";
import { HomePage } from "./pages/HomePage";
import { AboutPage } from "./pages/AboutPage";
import { SkillsPage } from "./pages/SkillsPage";
import { ProjectsPage } from "./pages/ProjectsPage";
import { ProjectDetailPage } from "./pages/ProjectDetailPage";
import { ExperiencePage } from "./pages/ExperiencePage";
import { ContactPage } from "./pages/ContactPage";

function RootLayout({
  darkMode,
  toggleDarkMode,
}: {
  darkMode: boolean;
  toggleDarkMode: () => void;
}) {
  return (
    <div className="min-h-screen flex flex-col font-[family-name:Inter] relative">
      <CursorGlow />
      <InteractiveBackground />
      <Navbar darkMode={darkMode} toggleDarkMode={toggleDarkMode} />
      <main className="flex-1 relative z-10">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== "undefined") {
      return window.matchMedia("(prefers-color-scheme: dark)").matches;
    }
    return false;
  });

  useEffect(() => {
    document.documentElement.classList.toggle("dark", darkMode);
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode((prev) => !prev);

  const router = useMemo(
    () =>
      createBrowserRouter([
        {
          path: "/",
          element: (
            <RootLayout darkMode={darkMode} toggleDarkMode={toggleDarkMode} />
          ),
          children: [
            { index: true, element: <HomePage /> },
            { path: "about", element: <AboutPage /> },
            { path: "skills", element: <SkillsPage /> },
            { path: "projects", element: <ProjectsPage /> },
            { path: "projects/:slug", element: <ProjectDetailPage /> },
            { path: "experience", element: <ExperiencePage /> },
            { path: "contact", element: <ContactPage /> },
          ],
        },
      ]),
    [darkMode]
  );

  return <RouterProvider router={router} />;
}