export type ProjectCategory = "all" | "fullstack" | "frontend" | "backend";

export interface Project {
  id: number;
  slug: string;
  title: string;
  description: string;
  longDescription: string;
  image: string;
  screenshots: string[];
  tags: string[];
  category: ProjectCategory[];
  github: string;
  demo: string;
  featured: boolean;
  role: string;
  duration: string;
  team: string;
  highlights: string[];
  challenges: { problem: string; solution: string }[];
}

export const projects: Project[] = [
  {
    id: 1,
    slug: "e-commerce-platform",
    title: "E-Commerce Platform",
    description:
      "Next.js와 NestJS로 구축한 풀스택 이커머스 플랫폼. 실시간 재고 관리, 결제 시스템 통합, 관리자 대시보드를 포함합니다.",
    longDescription:
      "대규모 트래픽을 처리할 수 있는 이커머스 플랫폼을 처음부터 설계하고 구축한 프로젝트입니다. Next.js의 App Router를 활용한 서버 사이드 렌더링으로 SEO를 최적화하고, NestJS 기반 마이크로서비스 아키텍처로 확장성을 확보했습니다. Stripe 결제 시스템 통합, Redis 캐싱을 통한 성능 최적화, 그리고 실시간 재고 관리 시스템까지 엔드투엔드로 구현했습니다.",
    image:
      "https://images.unsplash.com/photo-1577333715735-8fcb0359d906?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY29tbWVyY2UlMjB3ZWJzaXRlJTIwbW9ja3VwfGVufDF8fHx8MTc3MjA3ODIwMnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    screenshots: [
      "https://images.unsplash.com/photo-1642052503083-bc49dd433478?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlY29tbWVyY2UlMjB3ZWJzaXRlJTIwZGVza3RvcCUyMG1vY2t1cHxlbnwxfHx8fDE3NzIwODI2MTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    ],
    tags: ["Next.js", "NestJS", "PostgreSQL", "Stripe", "Redis"],
    category: ["fullstack"],
    github: "#",
    demo: "#",
    featured: true,
    role: "Team Lead / Full-Stack",
    duration: "2025.03 - 2025.08",
    team: "4명 (프론트 2, 백엔드 1, 디자이너 1)",
    highlights: [
      "Next.js App Router + SSR로 Lighthouse 성능 점수 95+ 달성",
      "NestJS 마이크로서비스 아키텍처로 서비스 분리 및 독립 배포 구현",
      "Stripe Webhook 기반 결제 파이프라인 구축, 99.9% 결제 성공률",
      "Redis 캐싱으로 상품 목록 API 응답시간 80% 단축",
      "실시간 재고 관리 시스템으로 동시 주문 충돌 해결",
      "관리자 대시보드에서 매출/주문/고객 통계 실시간 시각화",
    ],
    challenges: [
      {
        problem:
          "동시 주문 시 재고 수량 불일치 문제 — 여러 사용자가 동시에 같은 상품을 주문할 때 재고가 음수로 떨어지는 race condition이 발생했습니다.",
        solution:
          "PostgreSQL의 Advisory Lock과 Optimistic Locking을 조합하여 동시성 제어를 구현했습니다. 트랜잭션 격리 수준을 SERIALIZABLE로 설정하고, 재고 차감 시 version check를 적용하여 충돌 시 자동 재시도 로직을 추가했습니다.",
      },
      {
        problem:
          "상품 목록 페이지 로딩 속도 저하 — 상품 수가 1만 건을 넘어가면서 필터링+정렬 쿼리가 3초 이상 소요되었습니다.",
        solution:
          "복합 인덱스 최적화와 함께 Redis에 인기 상품 및 카테고리별 목록을 캐싱했습니다. Cursor-based pagination을 도입하고, ISR(Incremental Static Regeneration)로 정적 페이지를 주기적으로 재생성하여 응답시간을 200ms 이하로 단축했습니다.",
      },
    ],
  },
  {
    id: 2,
    slug: "analytics-dashboard",
    title: "Analytics Dashboard",
    description:
      "실시간 데이터 시각화 대시보드. WebSocket을 활용한 라이브 데이터 스트리밍과 커스텀 차트 컴포넌트를 구현했습니다.",
    longDescription:
      "기업 고객을 위한 실시간 데이터 분석 대시보드 프로젝트입니다. WebSocket을 통한 라이브 데이터 스트리밍, D3.js 기반 커스텀 차트 컴포넌트, 드래그 앤 드롭 대시보드 레이아웃 커스터마이징 등을 구현했습니다. 대규모 데이터셋을 효율적으로 렌더링하기 위해 가상화와 Web Worker를 활용한 데이터 처리 파이프라인을 설계했습니다.",
    image:
      "https://images.unsplash.com/photo-1759661966728-4a02e3c6ed91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXRhJTIwYW5hbHl0aWNzJTIwY2hhcnQlMjBkYXNoYm9hcmR8ZW58MXx8fHwxNzcxOTYzMTcxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    screenshots: [
      "https://images.unsplash.com/photo-1759752394755-1241472b589d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXNoYm9hcmQlMjBhbmFseXRpY3MlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzcyMDU0OTE1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    ],
    tags: ["React", "D3.js", "Socket.io", "Express", "MongoDB"],
    category: ["fullstack"],
    github: "#",
    demo: "#",
    featured: true,
    role: "Frontend Lead",
    duration: "2024.09 - 2025.01",
    team: "3명 (프론트 2, 백엔드 1)",
    highlights: [
      "WebSocket 기반 실시간 데이터 스트리밍, 100ms 이하 지연시간 달성",
      "D3.js로 10종 이상의 커스텀 인터랙티브 차트 컴포넌트 제작",
      "드래그 앤 드롭 레이아웃 커스터마이징 기능 구현",
      "Web Worker를 활용한 대규모 데이터 처리로 UI 블로킹 방지",
      "React.memo + useMemo 최적화로 60fps 차트 렌더링 유지",
    ],
    challenges: [
      {
        problem:
          "대규모 데이터 포인트(10만+) 렌더링 시 브라우저 프리징 — 실시간으로 들어오는 데이터를 차트에 반영할 때 메인 스레드가 블로킹되어 UI가 멈추는 현상이 발생했습니다.",
        solution:
          "Web Worker에서 데이터 집계 및 다운샘플링을 처리하고, requestAnimationFrame 기반 배치 업데이트를 구현했습니다. Canvas 렌더링으로 전환하고 LTTB(Largest Triangle Three Buckets) 알고리즘을 적용하여 시각적 품질 손실 없이 렌더링 포인트를 1/10로 줄였습니다.",
      },
    ],
  },
  {
    id: 3,
    slug: "social-media-app",
    title: "Social Media App",
    description:
      "React Native로 개발한 소셜 미디어 앱. 실시간 채팅, 스토리 기능, 이미지 업로드와 피드 알고리즘을 구현했습니다.",
    longDescription:
      "MZ세대를 타겟으로 한 관심사 기반 소셜 미디어 앱 프로젝트입니다. React Native로 iOS/Android 크로스 플랫폼을 지원하며, Firebase를 활용한 실시간 채팅과 스토리 기능, 머신러닝 기반 피드 추천 알고리즘을 구현했습니다. 이미지 최적화와 무한 스크롤 성능 개선에 특히 주력했습니다.",
    image:
      "https://images.unsplash.com/photo-1710870509663-16f20f75d758?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBzb2NpYWwlMjBtZWRpYXxlbnwxfHx8fDE3NzIwODEwNTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    screenshots: [
      "https://images.unsplash.com/photo-1710870509663-16f20f75d758?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBzb2NpYWwlMjBtZWRpYSUyMGludGVyZmFjZXxlbnwxfHx8fDE3NzIwODI2MTl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    ],
    tags: ["React Native", "Firebase", "Node.js", "GraphQL"],
    category: ["fullstack", "frontend"],
    github: "#",
    demo: "#",
    featured: false,
    role: "Full-Stack Developer",
    duration: "2024.04 - 2024.08",
    team: "5명 (프론트 2, 백엔드 2, 디자이너 1)",
    highlights: [
      "React Native로 iOS/Android 동시 배포, 코드 공유율 92%",
      "Firebase Realtime DB 기반 실시간 채팅, 읽음 확인 구현",
      "24시간 자동 소멸 스토리 기능 및 인터랙티브 리액션 구현",
      "GraphQL Subscription으로 피드 실시간 업데이트",
      "이미지 리사이징 + WebP 변환으로 업로드 용량 70% 절감",
    ],
    challenges: [
      {
        problem:
          "무한 스크롤 피드에서 메모리 누수 — 사용자가 오래 스크롤할수록 앱 메모리 사용량이 1GB를 초과하며 크래시가 발생했습니다.",
        solution:
          "FlashList로 마이그레이션하고 뷰포트 밖 이미지를 자동으로 언로드하는 커스텀 훅을 구현했습니다. 또한 Firestore 쿼리에 cursor-based pagination을 적용하고, 캐시 만료 정책을 설정하여 메모리 사용량을 300MB 이하로 안정화했습니다.",
      },
      {
        problem:
          "피드 알고리즘 성능 — 사용자 관심사와 소셜 그래프를 기반으로 피드를 정렬하는 로직이 서버에서 2초 이상 소요되었습니다.",
        solution:
          "사전 계산된 사용자별 피드 스코어를 Redis Sorted Set에 캐싱하고, 새 게시글 발행 시 비동기로 관련 사용자의 피드 스코어를 업데이트하는 이벤트 기반 아키텍처로 전환했습니다.",
      },
    ],
  },
  {
    id: 4,
    slug: "realtime-chat-system",
    title: "Real-time Chat System",
    description:
      "WebSocket 기반 실시간 채팅 시스템. 그룹 채팅, 파일 공유, 읽음 확인, 타이핑 인디케이터 등의 기능을 포함합니다.",
    longDescription:
      "엔터프라이즈급 실시간 채팅 시스템을 설계하고 구현한 프로젝트입니다. Socket.io를 활용한 양방향 통신, Redis Pub/Sub를 통한 다중 서버 메시지 브로드캐스팅, PostgreSQL 기반 메시지 영속성을 구현했습니다. 1:1 채팅, 그룹 채팅, 파일 공유, 읽음 확인, 타이핑 인디케이터 등 메신저의 핵심 기능을 모두 포함합니다.",
    image:
      "https://images.unsplash.com/photo-1591467454366-fb32b72b20e9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGF0JTIwbWVzc2FnaW5nJTIwYXBwbGljYXRpb24lMjBkYXJrfGVufDF8fHx8MTc3MjA4MjYyMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    screenshots: [
      "https://images.unsplash.com/photo-1662974770404-468fd9660389?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGF0JTIwYXBwbGljYXRpb24lMjBtZXNzYWdpbmd8ZW58MXx8fHwxNzcyMDgxMDYwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    ],
    tags: ["React", "Socket.io", "Redis", "Express", "PostgreSQL"],
    category: ["fullstack", "backend"],
    github: "#",
    demo: "#",
    featured: false,
    role: "Backend Developer",
    duration: "2024.01 - 2024.03",
    team: "3명 (프론트 1, 백엔드 2)",
    highlights: [
      "Socket.io + Redis Pub/Sub로 다중 서버 환경 실시간 메시지 동기화",
      "그룹 채팅방 최대 500명 동시 접속 지원, 메시지 지연 50ms 이하",
      "파일 공유 시 S3 Presigned URL 기반 직접 업로드로 서버 부하 최소화",
      "메시지 읽음 확인 및 타이핑 인디케이터 실시간 처리",
      "메시지 검색 기능 — PostgreSQL Full-Text Search 적용",
    ],
    challenges: [
      {
        problem:
          "다중 서버 환경에서의 메시지 동기화 — 로드 밸런서 뒤에 여러 서버 인스턴스가 있을 때, 다른 서버에 연결된 사용자에게 메시지가 전달되지 않는 문제가 있었습니다.",
        solution:
          "Redis Pub/Sub를 메시지 브로커로 도입하여 모든 서버 인스턴스 간 메시지를 브로드캐스팅했습니다. Socket.io의 Redis Adapter를 활용하고, 연결 끊김 시 미전달 메시지를 Redis Stream에 버퍼링하여 재연결 시 순서대로 전달하는 메커니즘을 구현했습니다.",
      },
    ],
  },
];
