import { Github, Linkedin, Mail, Heart } from "lucide-react";
import { motion } from "motion/react";
import { MagneticButton } from "./MagneticButton";

export function Footer() {
  return (
    <footer className="border-t border-border bg-background">
      <div className="max-w-6xl mx-auto px-6 py-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-muted-foreground text-[0.85rem] flex items-center gap-1.5 font-[family-name:Inter]">
            Built with{" "}
            <motion.span
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
            >
              <Heart className="w-4 h-4 text-red-500 fill-red-500" />
            </motion.span>{" "}
            using React & TypeScript
          </p>
          <div className="flex items-center gap-3">
            {[Github, Linkedin, Mail].map((Icon, i) => (
              <MagneticButton key={i}>
                <a
                  href="#"
                  className="w-9 h-9 rounded-lg border border-border flex items-center justify-center text-muted-foreground hover:text-violet-500 hover:border-violet-500/30 transition-all"
                >
                  <Icon className="w-4 h-4" />
                </a>
              </MagneticButton>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
