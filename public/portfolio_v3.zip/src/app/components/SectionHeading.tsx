import { motion } from "motion/react";
import { TextReveal } from "./TextReveal";

interface SectionHeadingProps {
  badge: string;
  title: string;
  description?: string;
}

export function SectionHeading({ badge, title, description }: SectionHeadingProps) {
  return (
    <div className="text-center mb-20">
      <motion.span
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.4 }}
        className="inline-block px-4 py-1.5 rounded-full bg-violet-500/10 text-violet-500 text-[0.8rem] mb-5 font-[family-name:'Fira_Code',monospace] tracking-wider"
      >
        {badge}
      </motion.span>
      <TextReveal
        as="h2"
        className="text-foreground font-[family-name:Inter] text-[2rem] md:text-[2.5rem] mb-5 leading-snug"
      >
        {title}
      </TextReveal>
      {description && (
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-muted-foreground max-w-xl mx-auto text-[1rem] font-[family-name:Inter] leading-relaxed"
        >
          {description}
        </motion.p>
      )}
    </div>
  );
}
