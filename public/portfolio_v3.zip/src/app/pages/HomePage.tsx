import { Link } from "react-router";
import { motion } from "motion/react";
import { ArrowRight, Download, Github, Linkedin, Mail, Terminal } from "lucide-react";
import { MagneticButton } from "../components/MagneticButton";
import { TextReveal } from "../components/TextReveal";
import { useEffect, useState } from "react";

function TypeWriter() {
  const lines = [
    "const developer = {",
    '  name: "김개발",',
    '  role: "Full-Stack Developer",',
    "  passion: true,",
    "};",
  ];
  const [currentLine, setCurrentLine] = useState(0);
  const [currentChar, setCurrentChar] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (done) return;
    if (currentLine >= lines.length) {
      setDone(true);
      return;
    }
    if (currentChar <= lines[currentLine].length) {
      const timer = setTimeout(() => setCurrentChar((c) => c + 1), 40);
      return () => clearTimeout(timer);
    }
    const timer = setTimeout(() => {
      setCurrentLine((l) => l + 1);
      setCurrentChar(0);
    }, 200);
    return () => clearTimeout(timer);
  }, [currentLine, currentChar, done, lines.length]);

  return (
    <div className="rounded-2xl bg-[#1a1a2e] border border-white/5 overflow-hidden shadow-2xl shadow-violet-500/5">
      {/* Terminal header */}
      <div className="px-4 py-3 bg-white/5 flex items-center gap-2">
        <div className="flex gap-1.5">
          <span className="w-3 h-3 rounded-full bg-red-400/80" />
          <span className="w-3 h-3 rounded-full bg-yellow-400/80" />
          <span className="w-3 h-3 rounded-full bg-green-400/80" />
        </div>
        <span className="text-white/30 text-[0.7rem] font-[family-name:'Fira_Code',monospace] ml-2 flex items-center gap-1.5">
          <Terminal className="w-3 h-3" />
          developer.ts
        </span>
      </div>
      {/* Code content */}
      <div className="p-5 font-[family-name:'Fira_Code',monospace] text-[0.8rem] leading-loose min-h-[180px]">
        {lines.map((line, i) => {
          if (i > currentLine) return null;
          const text = i < currentLine ? line : line.slice(0, currentChar);
          const hasColon = text.includes(":");
          const parts = hasColon ? text.split(":") : [text];

          return (
            <div key={i} className="flex">
              <span className="text-white/20 w-6 shrink-0 select-none text-right mr-4">
                {i + 1}
              </span>
              <span>
                {hasColon ? (
                  <>
                    <span className="text-cyan-400">{parts[0]}</span>
                    <span className="text-white/60">:</span>
                    <span className="text-amber-300">{parts.slice(1).join(":")}</span>
                  </>
                ) : (
                  <span className="text-violet-400">{text}</span>
                )}
                {i === currentLine && !done && (
                  <span className="inline-block w-[2px] h-[1em] bg-violet-400 ml-[1px] animate-pulse align-middle" />
                )}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

const stacks = [
  { label: "React", color: "bg-cyan-500/15 text-cyan-400 border-cyan-500/20" },
  { label: "TypeScript", color: "bg-blue-500/15 text-blue-400 border-blue-500/20" },
  { label: "Node.js", color: "bg-green-500/15 text-green-400 border-green-500/20" },
  { label: "PostgreSQL", color: "bg-indigo-500/15 text-indigo-400 border-indigo-500/20" },
  { label: "Next.js", color: "bg-white/10 text-white/70 border-white/10" },
  { label: "Docker", color: "bg-sky-500/15 text-sky-400 border-sky-500/20" },
];

export function HomePage() {
  return (
    <section className="min-h-screen flex items-center justify-center px-6 pt-20 pb-10 relative overflow-hidden">
      {/* Subtle gradient orbs */}
      <motion.div
        animate={{ scale: [1, 1.2, 1], opacity: [0.12, 0.18, 0.12] }}
        transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
        className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-violet-500 rounded-full blur-[160px] pointer-events-none"
      />
      <motion.div
        animate={{ scale: [1.2, 1, 1.2], opacity: [0.1, 0.15, 0.1] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
        className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-cyan-500 rounded-full blur-[160px] pointer-events-none"
      />

      <div className="max-w-6xl mx-auto w-full grid lg:grid-cols-2 gap-16 items-center relative z-10">
        {/* Left content */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-accent/60 border border-border/50 mb-8 backdrop-blur-sm"
          >
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500" />
            </span>
            <span className="text-[0.8rem] text-muted-foreground font-[family-name:Inter]">
              새로운 프로젝트에 열려있습니다
            </span>
          </motion.div>

          <TextReveal
            as="h1"
            className="text-foreground font-[family-name:Inter] text-[2.5rem] md:text-[3.25rem] leading-[1.15] mb-3"
          >
            안녕하세요,
          </TextReveal>

          <div className="mb-1">
            <TextReveal
              as="h1"
              delay={0.2}
              className="font-[family-name:Inter] text-[2.5rem] md:text-[3.25rem] leading-[1.15] bg-gradient-to-r from-violet-500 via-purple-500 to-cyan-500 bg-clip-text text-transparent"
            >
              풀스택 개발자
            </TextReveal>
          </div>

          <TextReveal
            as="h1"
            delay={0.35}
            className="text-foreground font-[family-name:Inter] text-[2.5rem] md:text-[3.25rem] leading-[1.15] mb-6"
          >
            김개발입니다.
          </TextReveal>

          {/* Code terminal - mobile only, above description */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="lg:hidden mb-8"
          >
            <TypeWriter />
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="text-muted-foreground text-[1.05rem] mb-8 max-w-lg font-[family-name:Inter] leading-[1.8]"
          >
            사용자 경험에 집중한 웹 애플리케이션을 설계하고 개발합니다.
            <br />
            3년 이상의 경험으로 효율적이고 확장 가능한 솔루션을 만듭니다.
          </motion.p>

          {/* Stack pills */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
            className="flex flex-wrap gap-2 mb-10"
          >
            {stacks.map((s, i) => (
              <motion.span
                key={s.label}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.8 + i * 0.06 }}
                whileHover={{ scale: 1.08, y: -2 }}
                className={`px-3 py-1.5 rounded-lg border text-[0.75rem] font-[family-name:'Fira_Code',monospace] cursor-default ${s.color}`}
              >
                {s.label}
              </motion.span>
            ))}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.9 }}
            className="flex flex-wrap gap-3 mb-10"
          >
            <MagneticButton>
              <Link
                to="/projects"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl bg-gradient-to-r from-violet-600 to-cyan-600 text-white text-[0.9rem] hover:shadow-lg hover:shadow-violet-500/25 transition-shadow font-[family-name:Inter]"
              >
                프로젝트 보기
                <ArrowRight className="w-4 h-4" />
              </Link>
            </MagneticButton>
            <MagneticButton>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-7 py-3.5 rounded-xl border border-border text-foreground text-[0.9rem] hover:bg-accent/50 transition-all font-[family-name:Inter] backdrop-blur-sm"
              >
                <Download className="w-4 h-4" />
                이력서 다운로드
              </Link>
            </MagneticButton>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.1 }}
            className="flex items-center gap-4"
          >
            <span className="text-muted-foreground text-[0.8rem] font-[family-name:Inter]">
              Follow me
            </span>
            <div className="h-px w-8 bg-border" />
            <div className="flex gap-2">
              {[
                { Icon: Github, label: "GitHub" },
                { Icon: Linkedin, label: "LinkedIn" },
                { Icon: Mail, label: "Email" },
              ].map(({ Icon, label }) => (
                <MagneticButton key={label}>
                  <a
                    href="#"
                    className="w-10 h-10 rounded-xl border border-border flex items-center justify-center text-muted-foreground hover:text-violet-500 hover:border-violet-500/30 hover:bg-violet-500/5 transition-all"
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                </MagneticButton>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Right - Code terminal (desktop only) */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="hidden lg:block"
        >
          <TypeWriter />
        </motion.div>
      </div>
    </section>
  );
}