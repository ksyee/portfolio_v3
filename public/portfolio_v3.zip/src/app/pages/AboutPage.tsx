import { motion } from "motion/react";
import { SectionHeading } from "../components/SectionHeading";
import { TiltCard } from "../components/TiltCard";
import { AnimatedCounter } from "../components/AnimatedCounter";
import {
  Code2,
  Server,
  Database,
  Palette,
  Users,
  Rocket,
} from "lucide-react";

const highlights = [
  {
    icon: Code2,
    title: "프론트엔드 개발",
    description:
      "React, Next.js, TypeScript로 모던하고 반응형인 UI를 구축합니다. 컴포넌트 기반 아키텍처와 상태 관리에 능숙합니다.",
    gradient: "from-cyan-500 to-blue-500",
  },
  {
    icon: Server,
    title: "백엔드 개발",
    description:
      "Node.js, Express, NestJS로 RESTful API와 GraphQL 서버를 구축합니다. 마이크로서비스 아키텍처 경험이 있습니다.",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    icon: Database,
    title: "데이터베이스 설계",
    description:
      "PostgreSQL, MongoDB, Redis를 활용한 효율적인 데이터 모델링과 쿼리 최적화를 수행합니다.",
    gradient: "from-violet-500 to-purple-500",
  },
  {
    icon: Palette,
    title: "UI/UX 디자인",
    description:
      "Figma를 활용한 프로토타이핑과 디자인 시스템 구축. 사용자 중심의 인터페이스를 설계합니다.",
    gradient: "from-pink-500 to-rose-500",
  },
  {
    icon: Users,
    title: "팀 협업",
    description:
      "Agile/Scrum 방법론 기반 협업. Git 기반 코드 리뷰와 CI/CD 파이프라인을 관리합니다.",
    gradient: "from-amber-500 to-orange-500",
  },
  {
    icon: Rocket,
    title: "DevOps & 배포",
    description:
      "Docker, AWS, Vercel을 활용한 안정적인 배포 환경 구축과 모니터링 시스템을 운영합니다.",
    gradient: "from-indigo-500 to-blue-600",
  },
];

const stats = [
  { value: "3+", label: "년 경력", icon: "💼" },
  { value: "20+", label: "완료 프로젝트", icon: "🚀" },
  { value: "10+", label: "기술 스택", icon: "⚡" },
  { value: "99%", label: "클라이언트 만족도", icon: "❤️" },
];

export function AboutPage() {
  return (
    <section className="min-h-screen px-6 pt-32 pb-20">
      <div className="max-w-6xl mx-auto">
        <SectionHeading
          badge="ABOUT ME"
          title="개발자 소개"
          description="끊임없이 배우고 성장하는 풀스택 개발자입니다"
        />

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-20">
          {stats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              whileHover={{ y: -5 }}
              className="text-center p-6 md:p-8 rounded-2xl bg-card border border-border hover:border-violet-500/20 transition-all group cursor-default"
            >
              <span className="text-2xl mb-3 block">{stat.icon}</span>
              <AnimatedCounter
                value={stat.value}
                className="block text-[2.5rem] bg-gradient-to-r from-violet-500 to-cyan-500 bg-clip-text text-transparent font-[family-name:Inter]"
              />
              <p className="text-muted-foreground text-[0.85rem] mt-1 font-[family-name:Inter]">
                {stat.label}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Highlights */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {highlights.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
            >
              <TiltCard className="h-full">
                <div className="p-6 bg-card border border-border h-full rounded-2xl hover:border-violet-500/20 transition-all group">
                  <div
                    className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center mb-5 shadow-lg opacity-90 group-hover:opacity-100 group-hover:scale-110 transition-all`}
                  >
                    <item.icon className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="text-foreground mb-3 font-[family-name:Inter]">
                    {item.title}
                  </h3>
                  <p className="text-muted-foreground text-[0.9rem] leading-[1.8] font-[family-name:Inter]">
                    {item.description}
                  </p>
                </div>
              </TiltCard>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
